// This program studies value incrementing
public class ImplementinVariable {
    public static void main(String[] args) {
	int Value = 12;

	System.out.println("Techniques of incrementing a value");

	Value++;
	System.out.print("Value = ");
	System.out.println(Value);

	Value++;
	System.out.print("Value = ");
	System.out.println(Value);
		
	Value++;
	System.out.print("Value = ");
	System.out.println(Value);
    }
}