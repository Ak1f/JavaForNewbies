//The Addition Operations


public class AdditionOp {
    public static void main(String[] args) {
        	System.out.print("244 + 835 = ");
	System.out.print(244 + 835);
    }
}