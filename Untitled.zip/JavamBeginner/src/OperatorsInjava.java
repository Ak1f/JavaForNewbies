//here operators in Java is used

public class OperatorsInjava {
	public static void main(String args[]) {
		int x = 10;
		System.out.println("x = " + x);
		System.out.println("++x degeri(value) = " + ++x);
		System.out.println("x = " + x);

		x = 10;
		System.out.println("x++ degeri = " + x++);
		System.out.println("x = " + x);

		x = 10;
		System.out.println("x-- degeri = " + x--);
		System.out.println("x = " + x);

		x = 10;
		System.out.println("--x degeri = " + --x);
		System.out.println("x = " + x);
	}
}