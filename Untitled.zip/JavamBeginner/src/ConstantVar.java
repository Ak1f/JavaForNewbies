
public class ConstantVar {

	// The following are examples of declaring constants:
	public static final int BOXWIDTH = 6;

	int value = 10;

	static final String TITLE = "MANAGER";

	public void changeValue() {

		value = 12; // will give an error }}
	}
}
